import glob,os
file_path = "/root/work/session"
xlsx_files = glob.glob(file_path + "/*.session")
for i in xlsx_files:
    ii=i.replace(file_path,'/root/work')
    py_file=ii.replace('.session','.py')
    open(py_file,'w+').write('from dj import work'+'\n'+'phone="'+i+'"\n'+'work(phone)')
    print(i)